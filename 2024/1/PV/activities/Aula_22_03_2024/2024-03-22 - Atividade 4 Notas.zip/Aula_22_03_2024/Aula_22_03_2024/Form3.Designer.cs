﻿namespace Aula_22_03_2024
{
    partial class frmBoletim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBoletim));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pbResultado = new System.Windows.Forms.PictureBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblMedia = new System.Windows.Forms.Label();
            this.lblSm = new System.Windows.Forms.Label();
            this.lblNotaDescarte = new System.Windows.Forms.Label();
            this.lblNd = new System.Windows.Forms.Label();
            this.lblLcst = new System.Windows.Forms.Label();
            this.lblMst = new System.Windows.Forms.Label();
            this.lblCn = new System.Windows.Forms.Label();
            this.lblCh = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblBoletim = new System.Windows.Forms.Label();
            this.lblCih = new System.Windows.Forms.Label();
            this.lblMast = new System.Windows.Forms.Label();
            this.lblLicst = new System.Windows.Forms.Label();
            this.lblCin = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbResultado)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::Aula_22_03_2024.Properties.Resources.calcMediaBgBoletim;
            this.panel1.Controls.Add(this.pbResultado);
            this.panel1.Controls.Add(this.lblResultado);
            this.panel1.Controls.Add(this.lblMedia);
            this.panel1.Controls.Add(this.lblSm);
            this.panel1.Controls.Add(this.lblNotaDescarte);
            this.panel1.Controls.Add(this.lblNd);
            this.panel1.Controls.Add(this.lblLcst);
            this.panel1.Controls.Add(this.lblMst);
            this.panel1.Controls.Add(this.lblCn);
            this.panel1.Controls.Add(this.lblCh);
            this.panel1.Controls.Add(this.lblName);
            this.panel1.Controls.Add(this.lblBoletim);
            this.panel1.Controls.Add(this.lblCih);
            this.panel1.Controls.Add(this.lblMast);
            this.panel1.Controls.Add(this.lblLicst);
            this.panel1.Controls.Add(this.lblCin);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(386, 306);
            this.panel1.TabIndex = 0;
            // 
            // pbResultado
            // 
            this.pbResultado.BackColor = System.Drawing.Color.White;
            this.pbResultado.Location = new System.Drawing.Point(308, 228);
            this.pbResultado.Name = "pbResultado";
            this.pbResultado.Size = new System.Drawing.Size(64, 64);
            this.pbResultado.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbResultado.TabIndex = 15;
            this.pbResultado.TabStop = false;
            // 
            // lblResultado
            // 
            this.lblResultado.BackColor = System.Drawing.Color.White;
            this.lblResultado.Font = new System.Drawing.Font("Cascadia Mono", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(287, 200);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(85, 20);
            this.lblResultado.TabIndex = 14;
            this.lblResultado.Text = "REPROVADO";
            this.lblResultado.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblMedia
            // 
            this.lblMedia.BackColor = System.Drawing.Color.White;
            this.lblMedia.Font = new System.Drawing.Font("Cascadia Mono", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedia.Location = new System.Drawing.Point(12, 235);
            this.lblMedia.Name = "lblMedia";
            this.lblMedia.Size = new System.Drawing.Size(110, 60);
            this.lblMedia.TabIndex = 13;
            this.lblMedia.Text = "0";
            this.lblMedia.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblSm
            // 
            this.lblSm.BackColor = System.Drawing.Color.White;
            this.lblSm.Font = new System.Drawing.Font("Cascadia Mono", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSm.Location = new System.Drawing.Point(12, 215);
            this.lblSm.Name = "lblSm";
            this.lblSm.Size = new System.Drawing.Size(110, 20);
            this.lblSm.TabIndex = 12;
            this.lblSm.Text = "SUA MÉDIA É:";
            this.lblSm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNotaDescarte
            // 
            this.lblNotaDescarte.BackColor = System.Drawing.Color.White;
            this.lblNotaDescarte.Font = new System.Drawing.Font("Cascadia Mono", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotaDescarte.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblNotaDescarte.Location = new System.Drawing.Point(337, 160);
            this.lblNotaDescarte.Name = "lblNotaDescarte";
            this.lblNotaDescarte.Size = new System.Drawing.Size(35, 20);
            this.lblNotaDescarte.TabIndex = 11;
            this.lblNotaDescarte.Text = "0";
            this.lblNotaDescarte.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblNd
            // 
            this.lblNd.BackColor = System.Drawing.Color.White;
            this.lblNd.Font = new System.Drawing.Font("Cascadia Mono", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNd.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblNd.Location = new System.Drawing.Point(12, 160);
            this.lblNd.Name = "lblNd";
            this.lblNd.Size = new System.Drawing.Size(334, 20);
            this.lblNd.TabIndex = 10;
            this.lblNd.Text = "Nota descarte..........................:";
            this.lblNd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblLcst
            // 
            this.lblLcst.BackColor = System.Drawing.Color.White;
            this.lblLcst.Font = new System.Drawing.Font("Cascadia Mono", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLcst.Location = new System.Drawing.Point(337, 120);
            this.lblLcst.Name = "lblLcst";
            this.lblLcst.Size = new System.Drawing.Size(35, 20);
            this.lblLcst.TabIndex = 9;
            this.lblLcst.Text = "0";
            this.lblLcst.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblMst
            // 
            this.lblMst.BackColor = System.Drawing.Color.White;
            this.lblMst.Font = new System.Drawing.Font("Cascadia Mono", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMst.Location = new System.Drawing.Point(334, 100);
            this.lblMst.Name = "lblMst";
            this.lblMst.Size = new System.Drawing.Size(38, 20);
            this.lblMst.TabIndex = 8;
            this.lblMst.Text = "0";
            this.lblMst.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCn
            // 
            this.lblCn.BackColor = System.Drawing.Color.White;
            this.lblCn.Font = new System.Drawing.Font("Cascadia Mono", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCn.Location = new System.Drawing.Point(339, 80);
            this.lblCn.Name = "lblCn";
            this.lblCn.Size = new System.Drawing.Size(33, 20);
            this.lblCn.TabIndex = 7;
            this.lblCn.Text = "0";
            this.lblCn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCh
            // 
            this.lblCh.BackColor = System.Drawing.Color.White;
            this.lblCh.Font = new System.Drawing.Font("Cascadia Mono", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCh.Location = new System.Drawing.Point(337, 60);
            this.lblCh.Name = "lblCh";
            this.lblCh.Size = new System.Drawing.Size(35, 20);
            this.lblCh.TabIndex = 6;
            this.lblCh.Text = "0";
            this.lblCh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblName
            // 
            this.lblName.BackColor = System.Drawing.Color.White;
            this.lblName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblName.Font = new System.Drawing.Font("Cascadia Mono", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(15, 29);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(357, 20);
            this.lblName.TabIndex = 5;
            this.lblName.Text = "Aqui vai o nome do aluno";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBoletim
            // 
            this.lblBoletim.BackColor = System.Drawing.Color.White;
            this.lblBoletim.Font = new System.Drawing.Font("Cascadia Mono", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBoletim.Location = new System.Drawing.Point(15, 9);
            this.lblBoletim.Name = "lblBoletim";
            this.lblBoletim.Size = new System.Drawing.Size(357, 20);
            this.lblBoletim.TabIndex = 4;
            this.lblBoletim.Text = "BOLETIM";
            this.lblBoletim.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCih
            // 
            this.lblCih.BackColor = System.Drawing.Color.White;
            this.lblCih.Font = new System.Drawing.Font("Cascadia Mono", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCih.Location = new System.Drawing.Point(12, 60);
            this.lblCih.Name = "lblCih";
            this.lblCih.Size = new System.Drawing.Size(334, 20);
            this.lblCih.TabIndex = 3;
            this.lblCih.Text = "Ciências Humanas.......................:";
            this.lblCih.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblMast
            // 
            this.lblMast.BackColor = System.Drawing.Color.White;
            this.lblMast.Font = new System.Drawing.Font("Cascadia Mono", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMast.Location = new System.Drawing.Point(12, 100);
            this.lblMast.Name = "lblMast";
            this.lblMast.Size = new System.Drawing.Size(334, 20);
            this.lblMast.TabIndex = 2;
            this.lblMast.Text = "Matemáticas e suas Tecnologias.........:";
            this.lblMast.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblLicst
            // 
            this.lblLicst.BackColor = System.Drawing.Color.White;
            this.lblLicst.Font = new System.Drawing.Font("Cascadia Mono", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLicst.Location = new System.Drawing.Point(12, 120);
            this.lblLicst.Name = "lblLicst";
            this.lblLicst.Size = new System.Drawing.Size(334, 20);
            this.lblLicst.TabIndex = 1;
            this.lblLicst.Text = "Linguagens, Código e suas Tecnologias..:";
            this.lblLicst.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCin
            // 
            this.lblCin.BackColor = System.Drawing.Color.White;
            this.lblCin.Font = new System.Drawing.Font("Cascadia Mono", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCin.Location = new System.Drawing.Point(12, 80);
            this.lblCin.Name = "lblCin";
            this.lblCin.Size = new System.Drawing.Size(334, 20);
            this.lblCin.TabIndex = 0;
            this.lblCin.Text = "Ciências da Natureza...................:";
            this.lblCin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // frmBoletim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 304);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmBoletim";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BOLETIM DE";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbResultado)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblCin;
        private System.Windows.Forms.Label lblCih;
        private System.Windows.Forms.Label lblMast;
        private System.Windows.Forms.Label lblLicst;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblBoletim;
        private System.Windows.Forms.Label lblLcst;
        private System.Windows.Forms.Label lblMst;
        private System.Windows.Forms.Label lblCn;
        private System.Windows.Forms.Label lblCh;
        private System.Windows.Forms.Label lblNotaDescarte;
        private System.Windows.Forms.Label lblNd;
        private System.Windows.Forms.Label lblMedia;
        private System.Windows.Forms.Label lblSm;
        private System.Windows.Forms.PictureBox pbResultado;
        private System.Windows.Forms.Label lblResultado;
    }
}